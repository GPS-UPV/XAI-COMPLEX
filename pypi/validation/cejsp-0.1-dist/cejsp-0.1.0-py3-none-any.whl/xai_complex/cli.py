import argparse
import json
from pathlib import Path



def main(argv=None):
    parser = argparse.ArgumentParser(prog="cejsp", description="CEJSP: JSP Complexity Estimator")
    sub = parser.add_subparsers(dest="command", required=True)
    fit = sub.add_parser("fit")
    fit.add_argument("input", help="JSON list of numeric feature dictionaries")
    fit.add_argument("model")
    fit.add_argument("--targets", help="Optional JSON list of calibrated [0,1] solver targets")
    predict = sub.add_parser("predict")
    predict.add_argument("input")
    predict.add_argument("model")
    predict.add_argument("--trust-model", action="store_true", help="Allow loading a trusted joblib file")
    args = parser.parse_args(argv)
    try:
        from .estimator import ComplexityEstimator
        rows = json.loads(Path(args.input).read_text(encoding="utf-8"))
        if args.command == "fit":
            y = json.loads(Path(args.targets).read_text(encoding="utf-8")) if args.targets else None
            ComplexityEstimator().fit(rows, y).save(args.model)
        else:
            model = ComplexityEstimator.load(args.model, trusted=args.trust_model)
            print(json.dumps(model.predict(rows), indent=2, allow_nan=False))
    except (ValueError, OSError, ImportError, KeyError) as exc:
        parser.exit(2, f"cejsp: {exc}\n")


if __name__ == "__main__":
    main()
