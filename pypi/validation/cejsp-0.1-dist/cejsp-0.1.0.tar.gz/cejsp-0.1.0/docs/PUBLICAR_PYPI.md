# Publicación posterior

No se ha publicado. No publicar esta candidata mientras haya pruebas omitidas o comprobaciones bloqueadas. El nombre `cejsp` y la versión `0.1.0` son propuestas; su disponibilidad no está comprobada.

Desde PowerShell, ejecutar con un Python ejecutable y acceso a las dependencias:

```powershell
Set-Location 'D:\CODE\XAI-COMPLEX'
& .\pypi\VALIDAR_WINDOWS.ps1 -Python python
```

El script instala `.[graphs,dev]`, exige pruebas sin omisiones, comprueba los JSON existentes y el flujo completo con 20 benchmarks, construye wheel y sdist, ejecuta `twine check --strict` y prueba las dos distribuciones en entornos separados con Python aislado (`-I`). Se detiene ante cualquier error. Los resultados quedan en `pypi/validacion-FECHA/`. Si los benchmarks están en otra ubicación, usar `-Instancias 'RUTA'`.

Tras una ejecución satisfactoria, y solo cuando se autorice la publicación, seleccionar la carpeta exacta de esa ejecución:

```powershell
$release = Get-ChildItem .\pypi -Directory -Filter 'validacion-*' | Sort-Object Name | Select-Object -Last 1
$pythonRelease = Join-Path $release.FullName 'entorno\Scripts\python.exe'
$artifacts = @(Get-ChildItem (Join-Path $release.FullName 'dist') -File | ForEach-Object FullName)
& $pythonRelease -m twine check --strict @artifacts
& $pythonRelease -m twine upload --repository testpypi @artifacts
```

Comprobar que esa ejecución terminó con `VALIDACION COMPLETA SIN OMISIONES`. No elegir una ejecución fallida por ser la más reciente. Twine solicita las credenciales: usuario `__token__` y token específico del servicio. No guardar credenciales en el repositorio.

Comprobar TestPyPI en otro entorno, descargando el paquete sin mezclar índices:

```powershell
python -m venv .testpypi-check
& .\.testpypi-check\Scripts\python.exe -m pip download --index-url https://test.pypi.org/simple/ --no-deps cejsp==0.1.0 --dest .testpypi-download
& .\.testpypi-check\Scripts\python.exe -m pip install '.\.testpypi-download\cejsp-0.1.0-py3-none-any.whl[graphs]'
& .\.testpypi-check\Scripts\python.exe -I .\pypi\verify_release.py
& .\.testpypi-check\Scripts\python.exe -I .\pypi\validate_pipeline.py .\TaillardInstancesJSON
```

Después de comprobar TestPyPI y recibir autorización para PyPI:

```powershell
& $pythonRelease -m twine upload @artifacts
```

Si el nombre está ocupado, cambiar `project.name` y reconstruir. Para una versión publicada, incrementar la versión en `pyproject.toml` y `src/xai_complex/__init__.py`, sincronizar la copia auxiliar de la raíz y volver a validar. Una versión publicada no se sustituye.

Documentación oficial: https://packaging.python.org/en/latest/tutorials/packaging-projects/ y https://twine.readthedocs.io/en/stable/.

El cambio de nombre requiere una nueva ejecución completa de VALIDAR_WINDOWS.ps1. Publicar únicamente artefactos cejsp-0.1.0* de esa ejecución, nunca los xai_complex de validaciones anteriores.
