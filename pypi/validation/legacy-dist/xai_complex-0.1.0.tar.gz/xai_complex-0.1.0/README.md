# XAI-COMPLEX

Estimación empírica de dificultad de instancias de scheduling ya generadas. Este paquete no genera instancias ni modifica IGJSP.

El código procede del proyecto XAI-COMPLEX. Conserva el extractor de características de grafos y ofrece la metodología por lotes del estimador ponderado, además de una API explícita para ajustar una referencia y predecir nuevas instancias sin recalibrar cada lote.

## Instalación

```powershell
python -m pip install .
python -m pip install ".[graphs,dev]"
```

El extra `graphs` instala las dependencias del extractor original. No se necesita IGJSP para instalar ni utilizar XAI-COMPLEX con instancias guardadas o características extraídas.

## Usar instancias que ya tienes

```python
import json
from pathlib import Path
from xai_complex.graphs import extract_instance_features
from xai_complex import ComplexityEstimator

instances = [json.loads(p.read_text(encoding="utf-8"))
             for p in Path("instancias_existentes").glob("*.json")]
features = [extract_instance_features(inst) for inst in instances]
model = ComplexityEstimator().fit(features)
resultados = model.predict(features[:1])
model.save("referencia.joblib")
```

Se necesitan al menos tres instancias de referencia con variación; para una calibración útil se requiere un conjunto representativo y una evaluación independiente. No se distribuye un modelo preentrenado ni se afirma precisión predictiva sin evaluación.

Para evaluar una instancia nueva se carga la referencia ya ajustada:

```python
model = ComplexityEstimator.load("referencia.joblib", trusted=True)
resultado = model.predict([extract_instance_features(instancia_nueva)])
```

Solo se deben cargar modelos de confianza. Se verifican esquema y versiones de dependencias del artefacto.

## Mantener el análisis por lotes del proyecto

```python
import pandas as pd
from xai_complex import estimate_features

features = pd.read_csv("graphs/features.csv").set_index("file")
scores = estimate_features(features)
scores.to_csv("complexity_scores.csv")
```

Esta ruta conserva Isolation Forest, LOF, MinCovDet, vecinos y prior del estimador ponderado. Sus normalizaciones y categorías son relativas al lote. La API `ComplexityEstimator` congela la referencia; usa los mismos cuatro tipos de señal sin prior y, opcionalmente, mezcla regresión supervisada. Es una variante inductiva explícita, no una reproducción numérica idéntica del análisis por lotes.

La extracción usa el grafo JSP original. Las instancias con varias velocidades requieren `speed_index` explícito. El adaptador de entrada conserva todas las velocidades, fechas y disponibilidad; el extractor original rechaza FJSP porque su grafo de rutas fijas no modela la elección de máquina. No se declara compatibilidad científica con FJSP sin validar esa representación.

`summarize_instance` ofrece estadísticas descriptivas; no sustituye las características de grafos del estimador original.

## Etiquetas y evaluación

`SolverTargetCalibrator` calibra señales de solver en el entrenamiento y mantiene fijos esos parámetros. `evaluate_supervised` ajusta objetivo y preprocesamiento dentro de cada pliegue. Usa `base_instance_id` o grupos equivalentes para que variantes de una misma instancia no aparezcan en entrenamiento y validación. Las etiquetas miden dificultad empírica respecto al solver, hardware y límites de tiempo; no una clase de complejidad computacional.

Las correcciones de etiquetas cambian los resultados anteriores: se rechazan objetivos sin señales, se validan pesos, se renormalizan componentes disponibles y se conserva el significado absoluto del estado del solver.

## Comandos

```powershell
xai-complex fit reference_features.json referencia.joblib
xai-complex predict query_features.json referencia.joblib --trust-model
python -m unittest discover -s tests -v
```

Los JSON de la CLI contienen listas de diccionarios de características numéricas, sin identificadores de texto. Los identificadores se mantienen por separado o en el índice del DataFrame para la API por lotes.

Consulta `docs/PUBLICAR_PYPI.md` para construir, verificar y publicar.

## Estado de esta candidata

La ejecución del usuario del 22/10/2026 instaló dependencias, superó las 28 pruebas originales sin omisiones y validó los 162 JSON reales. El flujo real falló al comparar predicciones mediante igualdad exacta. El verificador ahora utiliza tolerancia numérica estricta y conserva la igualdad de categorías y señales; tres regresiones nuevas del comparador pasan, pero falta repetir el flujo completo corregido y los pasos posteriores de publicación. Consultar `RESULTADOS.md` en la raíz del repositorio para distinguir esta ejecución de las sesiones restringidas del agente.

Las etiquetas necesitan el mismo identificador completo que las características. No se infieren correspondencias a partir del tamaño, configuración o semilla, ni se promedian registros repetidos automáticamente. Por ejemplo, `10_10-0-1-cp-sat` no se convierte silenciosamente en `10-10-0.pt`: la configuración y el protocolo del solver deben resolverse antes mediante una correspondencia explícita y verificada. Para variantes, incluir `base_instance_id` en todas las etiquetas o pasar `groups` a `evaluate_supervised`; el resultado incluye los índices de cada pliegue para auditar su separación.

`fit_instances(..., speed_index=...)` y `predict_instances(..., speed_index=...)` permiten la proyección explícita de velocidad. La invariancia por lote pertenece a la API inductiva; no se exige al análisis relativo por lotes.
