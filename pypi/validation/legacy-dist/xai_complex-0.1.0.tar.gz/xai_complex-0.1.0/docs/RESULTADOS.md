# Estado de la entrega

Fecha: 22 de octubre de 2026.

## Alcance

Correcciones de XAI-COMPLEX y carpeta de distribución independiente. IGJSP no se modifica, no se incluye como dependencia y no se genera ninguna instancia. El paquete recibe instancias existentes o sus características.

Las modificaciones están preparadas en una copia: el entorno no permite escribir en D:\CODE\XAI-COMPLEX. APLICAR_CAMBIOS.ps1 comprueba hashes y prepara copias de seguridad antes de trasladarlas al repositorio original; no se ha ejecutado sobre ese directorio.

## Cambios

- Estado INFEASIBLE separado de FEASIBLE.
- Límites de vecinos según el número de muestras y error explícito para referencias insuficientes.
- Preprocesamiento y calibración del objetivo ajustados dentro de cada pliegue en los estimadores ponderados.
- Evaluación supervisada compartida; cada modelo de validación se entrena una vez y se reutiliza para obtener sus predicciones.
- Rechazo de etiquetas sin señales, pesos inválidos, identificadores ambiguos y objetivos constantes.
- Renormalización de pesos por señales disponibles; el estado del solver conserva su escala absoluta.
- Exportación de características sin eliminar la última fila ni forzar semilla cero.
- Retirada de la supresión global de avisos.
- Fechas por trabajo expandidas a sus operaciones y selección explícita de velocidad antes de construir el grafo original.
- Rechazo explícito de FJSP en el grafo de rutas fijas; no se convierte silenciosamente en JSP.
- Semilla fija en centralidad aproximada y propagación de errores de generación de grafos.
- Limpieza de comentarios decorativos y comprobación de que esa pasada conserva el AST.
- API de análisis por lotes basada en el estimador ponderado original, más variante inductiva explícita con referencia persistente.

El estimador básico estimate_complexity.py conserva su carácter experimental: se corrigen incompatibilidades dimensionales y tamaños fijos, y los identificadores arbitrarios de KMeans se sustituyen por distancia al centroide. Esta corrección cambia sus puntuaciones. Para el paquete se usa como referencia el estimador ponderado, no esa variante experimental.

## Validación

- Pruebas de contratos de entrada, fechas, velocidades, disponibilidad, etiquetas y regresiones de código ejecutadas con Python 3.12.14.
- 23 pruebas descubiertas: 16 pasan y 7 se omiten por dependencias ausentes.
- Las 7 omitidas cubren el estimador, persistencia, invariancia por lote, evaluación agrupada e integración de grafos. No se consideran aprobadas.
- Los contratos utilizan fixtures sintéticos. Además se comprobaron normalización y estadísticas descriptivas de los 162 JSON reales de TaillardInstancesJSON: 162 pasan tras corregir el rechazo de una operación de duración cero en orb07, presente también en el archivo original. Esta comprobación no ejecuta grafos ni el estimador, y no demuestra compatibilidad con todos los objetos de IGJSP.
- Compilación sintáctica de los módulos del paquete y de la copia de scripts.
- Construcción de wheel y sdist con setuptools. Instalación del wheel en un entorno aislado usando --no-deps; esto solo valida distribución e importaciones ligeras.
- No se ha podido ejecutar twine check ni instalar las dependencias ausentes: las descargas fallan con error de resolución DNS. No se ha publicado en TestPyPI ni PyPI.
- No hay mediciones de rendimiento ni resultados científicos nuevos. No se afirma equivalencia numérica con resultados anteriores tras corregir etiquetas y validación.

## Pendiente antes de publicar

Se ha repetido la instalación de las dependencias en un entorno separado, tanto con la configuración disponible como indicando PyPI explícitamente: falla. La consulta directa a PyPI devuelve error de resolución DNS. La caché contiene binarios para Python 3.11, pero ese intérprete devuelve acceso denegado al ejecutarlo en esta sesión; el intérprete ejecutable disponible es Python 3.12.14. No se ha eludido esa restricción ni se han sustituido las bibliotecas por simulaciones.

VALIDAR_WINDOWS.ps1 realiza la validación completa desde un PowerShell con acceso a las dependencias. Su sintaxis ha sido comprobada. No está ejecutado con éxito aquí.

Instalar .[graphs,dev], ejecutar verify_release.py sin omisiones, verificar las rutas ponderadas con los CSV reales del proyecto y probar extracción con JSON/objetos reales guardados. Ejecutar twine check, instalar el sdist y validar TestPyPI según PUBLICAR_PYPI.md. Hasta entonces esta entrega es una candidata de trabajo, no una versión completamente validada.

## Revisión antislop posterior

PASS, R-31: comentarios decorativos retirados; la pasada de comentarios verifica igualdad de AST.
PASS, R-36: el informe distingue resultados ejecutados y pruebas bloqueadas; no se inventan métricas.
Las reglas de UI, navegación, tipografía y accesibilidad no aplican a esta biblioteca Python.
La validación funcional de publicación permanece pendiente; no se declara un PASS global.
