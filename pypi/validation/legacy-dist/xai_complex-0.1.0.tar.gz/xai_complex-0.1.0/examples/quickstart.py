import json
from pathlib import Path
from xai_complex import ComplexityEstimator

reference = json.loads(Path("reference_features.json").read_text(encoding="utf-8"))
model = ComplexityEstimator().fit(reference)
model.save("reference.joblib")
query = json.loads(Path("query_features.json").read_text(encoding="utf-8"))
print(model.predict(query))
